package example.dvdrentalservice;

//import antlr.StringUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import example.repository.dvdrentalRepository;

import java.util.List;
import java.util.Map;

@Service
public class dvdrentalService {
    dvdrentalRepository DvdrentalRepository;

    @Autowired
    @Qualifier("mariaJdbcTemplate")
    private JdbcTemplate mariaJdbcTemplate;

    public List<Map<String, Object>> getdata() {
        try {
            List<Map<String, Object>> data;
            String query = DvdrentalRepository.display1;
            data = mariaJdbcTemplate.queryForList(query);
            System.out.println(data);
            return data;
        } catch (Exception e) {
            System.out.println("Exception");
            throw e;
        }
    }


    public String getdataInsert() {
        List<Map<String, Object>> partData = mariaJdbcTemplate.queryForList(DvdrentalRepository.details);
        String sample =  "",actorid, firstname, lastname;
        String output_query = "";
        for (Map m : partData) {
            actorid = m.get("actor_id").toString();
            lastname = (String) m.get("last_name");
            firstname = (String) m.get("first_name");
            String query = DvdrentalRepository.insert1;
            query = StringUtils.replaceEachRepeatedly(query,
                    new String[]{"actorid", "firstname", "lastname"},
                    new String[]{actorid, firstname, lastname});
            mariaJdbcTemplate.execute(query);


            output_query = "\n" + query;
            System.out.println("Query to be executed \n ----------------------" + query + "------------------------");
        }System.out.println(sample);
        System.out.println(output_query);
        return output_query;
    }
}


